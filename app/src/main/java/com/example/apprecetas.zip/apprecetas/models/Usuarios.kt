package com.example.apprecetas.models

data class Usuario(
    val nombre: String,
    val apellido: String,
    val email: String,
    val passwd: String
)
